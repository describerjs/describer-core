﻿using System.Collections.Generic;

namespace $safeprojectname$.Data
{
	public interface IExampleDataRepository
	{
		List<string> GetData();

        string GetDatabyIndex(int index);
	}
}
