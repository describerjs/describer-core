﻿using System.Collections.Generic;

namespace $safeprojectname$.Model
{
	public interface IStartModel
	{
		List<IContactRequest> ContactRequests { get; set; }

		IPersonalData PersonalData { get; set; }
	}
}