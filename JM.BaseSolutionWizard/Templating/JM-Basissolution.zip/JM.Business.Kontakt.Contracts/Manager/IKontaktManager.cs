﻿using $safeprojectname$.Model;
using System.Collections.Generic;

namespace $safeprojectname$.Manager
{
	public interface IKontaktManager
	{
		IContactModel GetContactModel();

		IStartModel GetStartModel(string userID = "");

		void SendContactMail(IContactModel model);

		IPersonalData GetPersonalData(string userID);

		List<IContactRequest> GetContactRequests(string userID);

		bool SavePersonalData(IPersonalData model);

		IFamilyModel GetFamilyModel(string userID);
	}
}
