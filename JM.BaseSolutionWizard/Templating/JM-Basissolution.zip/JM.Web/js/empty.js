define(function (){
	return {};
});