using System.ComponentModel.DataAnnotations;

namespace $safeprojectname$.Infrastructure.Models
{
    public class ForgotPasswordViewModel
    {
        [Required]
        [EmailAddress]
        [Display(Name = "E-Mail")]
        public string Email { get; set; }
    }
}