using System;
using System.Configuration;

namespace $safeprojectname$
{
    internal class SmtpServerElement : ConfigurationElement
    {
        [ConfigurationProperty("server", IsRequired = true)]
        public string Server
        {
            get { return this["server"] as string; }
        }
    }
}