﻿using $safeprojectname$.Contracts.Model;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace $safeprojectname$.Business.Model
{
	public class FamilyModel : IFamilyModel
	{
		[Required]
		public string UserID { get; set; }

		[DisplayName("Familienname")]
		[Required(AllowEmptyStrings = false, ErrorMessage = "Bitte geben Sie einen Familiennamen an")]
		[RegularExpression(@"^[a-zA-Z]{10,20}$")]
		public string FamilyName { get; set; }

		[Required(ErrorMessage = "Bitte geben Sie alle Daten für Ihren Vater an")]
		public IPersonalData Father { get; set; }

		[Required(ErrorMessage = "Bitte geben Sie alle Daten für Ihre Mutter an")]
		public IPersonalData Mother { get; set; }
	}
}
