﻿using Autofac.Extras.DynamicProxy2;
using $safeprojectname$.Business.Model;
using $safeprojectname$.Contracts.Manager;
using $safeprojectname$.Contracts.Model;
using $safeprojectname$.DataAccess;
using $safeprojectname$.DataModel;
using JM.Foundation;
using JM.Foundation.Configuration;
using JM.Foundation.ErrorHandling;
using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Net.Mail;
using $safeprojectname$.Configuration;

namespace $safeprojectname$.Business.Manager
{
	[SystemBoundary("CustomerCare", BusinesImpact.Low)]
	[Intercept(typeof(ErrorInterceptor))]
	public class KontaktManager : IKontaktManager
	{
		private Config _config;

		public KontaktManager()
		{
			_config = ApplicationConfiguration.GetConfigSection<Config>("$safeprojectname$");
		}

		public IContactModel GetContactModel()
		{
			return new ContactModel();
		}

		public IStartModel GetStartModel(string userID = "")
		{
			var personalData = GetPersonalData(userID);
			var contactRequests = GetContactRequests(userID);
			var model = new StartModel
			{
				PersonalData = personalData,
				ContactRequests = contactRequests
			};

			return model;
		}

		public void SendContactMail(IContactModel model)
		{
			var mail = new MailMessage(model.Email, _config.Mailing.RecipientAdress);

			mail.Subject = 
                string.Format(
                    "{0}{1}", 
                    _config.Mailing.SubjectPrefix,
				    string.IsNullOrEmpty(model.Subject) ? _config.Mailing.DefaultSubject : model.Subject);

			mail.Body = string.Format("Mail vom {0}{1}", DateTime.Now, Environment.NewLine);
			mail.Body += string.Format("Absender: {0} {1} {2} {3}{3}", model.Salutation, model.FirstName, model.LastName, Environment.NewLine);
			mail.Body += model.Message;

            if (_config.Mailing.SendAsHighPriorityMail)
            {
                mail.Priority = MailPriority.High;
            }

			// Loggen des Aufrufs
            // ToDo: New durch statisches Log() ersetzen.
			new ModuleEvents().ContactFormSent(model.Email, model.FirstName, model.LastName);

			var sender = new SmtpClient(_config.SmtpServer.Server);
			sender.Send(mail);

			SaveContactRequest(model);
		}

		public IFamilyModel GetFamilyModel(string userID)
		{
			return new FamilyModel { UserID = userID, Father = new Model.PersonalData(), Mother = new Model.PersonalData() };
		}

        public IPersonalData GetPersonalData(string userID)
		{
			IPersonalData data = null;

			using (var db = new Data(_config.ConnectionString.Value))
			{
				data = db.CustomerData.FirstOrDefault(u => u.UserID == userID);
			}

			return data ?? (data = new Model.PersonalData { UserID = userID });
		}

		public List<IContactRequest> GetContactRequests(string userID)
		{
			IEnumerable<IContactRequest> data = new List<IContactRequest>();

			using (var db = new Data(_config.ConnectionString.Value))
			{
				data = db.ContactRequest.Where(u => u.UserID == userID).ToList();
			}

			return data.ToList();
		}

		public bool SavePersonalData(IPersonalData model)
		{
			var data = new $safeprojectname$.DataModel.PersonalData
			{
				CreatedAt = model.CreatedAt,
				Email = model.Email,
				UserID = model.UserID,
				Salutation = model.Salutation,
				FirstName = model.FirstName,
				ID = model.ID,
				LastEditAt = model.LastEditAt,
				LastName = model.LastName,
				Mobile = model.Mobile,
				PostCode = model.PostCode
			};

			using (var db = new Data(_config.ConnectionString.Value))
			{
				if (data.ID == 0)
				{
					data.CreatedAt = DateTime.Now;
				}

				db.CustomerData.AddOrUpdate(data);
				db.SaveChanges();
			}

			return true;
		}
		
        private void SaveContactRequest(IContactModel model)
		{
			var entry = new ContactRequest
			{
				CreatedAt = DateTime.Now,
				Message = model.Message,
				Subject = model.Subject,
				UserID = model.UserID
			};

			using (var db = new Data(_config.ConnectionString.Value))
			{
				db.ContactRequest.Add(entry);
				db.SaveChanges();
			}
		}
	}
}