﻿using $safeprojectname$.DataModel;
using System.Data.Entity;

namespace $safeprojectname$.DataAccess
{
    public class Data : DbContext
    {
        public Data() : base("DefaultConnection")
        { }

        public Data(string connectionString) : base(connectionString)
        { }

        public DbSet<PersonalData> CustomerData { get; set; }

        public DbSet<ContactRequest> ContactRequest { get; set; }
    }
}