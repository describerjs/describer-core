using System;
using System.Configuration;

namespace $safeprojectname$.Configuration
{
    internal class ConnectionString : ConfigurationElement
    {
        [ConfigurationProperty("value", IsRequired = true)]
        public string Value
        {
            get { return this["value"] as string; }
        }
    }
}