namespace $safeprojectname$.Areas.JMDemo.Models
{
    public class StringManagerModel
    {
        public int ID
        {
            get;
            set;
        }

        public string String
        {
            get;
            set;
        }

        public string Manager
        {
            get;
            set;
        }
    }
}