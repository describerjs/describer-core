namespace $safeprojectname$.Infrastructure.Models
{
    public class ExternalLoginListViewModel
    {
        public string Action
        {
            get;
            set;
        }

        public string ReturnUrl
        {
            get;
            set;
        }
    }
}